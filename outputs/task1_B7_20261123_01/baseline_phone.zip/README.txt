BirdBox diagnostic snapshot
All locally retained records at the snapshot cutoff are in full_trace.json.
Phone records are in phone_diagnostics; box logs are a separate source.
See retention for dropped/unknown history; a short summary is not the full trace.
full_trace.json SHA-256: 286149093b01bca9e4e43aec6b696059521b9bc6e28977bc06c12ab259161c41
The shared ZIP SHA-256 is shown by the App and is not embedded in itself.
