BirdBox diagnostic snapshot
All locally retained records at the snapshot cutoff are in full_trace.json.
Phone records are in phone_diagnostics; box logs are a separate source.
See retention for dropped/unknown history; a short summary is not the full trace.
full_trace.json SHA-256: f43f389a7b3c9c4a67958aec338c3acf9b2e0bfba5acad800228c779432921f4
The shared ZIP SHA-256 is shown by the App and is not embedded in itself.
