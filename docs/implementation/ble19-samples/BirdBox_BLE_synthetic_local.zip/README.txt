BirdBox BLE diagnostic snapshot
All locally retained records at the snapshot cutoff are in full_trace.json.
See retention for dropped/unknown history; a short summary is not the full trace.
full_trace.json SHA-256: 0bce6bd4300ad8658f7531ff56bf9443c4af7ed364cd8ebde925b062cfc029b7
The shared ZIP SHA-256 is shown by the App and is not embedded in itself.
